import hashlib

class HierarchicalVerification:
    def __init__(self):
        self.verified_data = {}

    def verify_data(self, data):
        hash_value = hashlib.sha256(data.encode()).hexdigest()
        self.verified_data[data] = hash_value
        return hash_value

    def check_integrity(self, data):
        return self.verified_data.get(data) == hashlib.sha256(data.encode()).hexdigest()

if __name__ == "__main__":
    hv = HierarchicalVerification()
    data = "Secure data for verification"
    hash_value = hv.verify_data(data)
    print(f"Hash Value: {hash_value}")
    print(f"Integrity Check: {hv.check_integrity(data)}")