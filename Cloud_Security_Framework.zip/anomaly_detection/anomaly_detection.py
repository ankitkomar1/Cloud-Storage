import numpy as np
from sklearn.ensemble import IsolationForest

class AnomalyDetection:
    def __init__(self):
        self.model = IsolationForest(contamination=0.1)

    def train_model(self, data):
        self.model.fit(data)

    def detect_anomalies(self, new_data):
        return self.model.predict(new_data)

if __name__ == "__main__":
    ad = AnomalyDetection()
    sample_data = np.random.rand(100, 2)
    ad.train_model(sample_data)
    test_data = np.random.rand(10, 2)
    anomalies = ad.detect_anomalies(test_data)
    print(f"Anomaly Results: {anomalies}")