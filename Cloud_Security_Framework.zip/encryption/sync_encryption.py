import hashlib
import os

class SyncEncryption:
    def __init__(self, key):
        self.key = hashlib.sha256(key.encode()).digest()

    def encrypt(self, data):
        encrypted_data = bytes([b ^ self.key[i % len(self.key)] for i, b in enumerate(data.encode())])
        return encrypted_data

    def decrypt(self, encrypted_data):
        decrypted_data = bytes([b ^ self.key[i % len(self.key)] for i, b in enumerate(encrypted_data)])
        return decrypted_data.decode()

if __name__ == "__main__":
    se = SyncEncryption("secure_key")
    data = "Confidential cloud data"
    encrypted_data = se.encrypt(data)
    print(f"Encrypted Data: {encrypted_data}")
    print(f"Decrypted Data: {se.decrypt(encrypted_data)}")